#pragma once
#include "stdio.h"

char logDebug(char a);
