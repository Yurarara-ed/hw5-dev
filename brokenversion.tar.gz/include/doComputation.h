#pragma once

int doComputation();
