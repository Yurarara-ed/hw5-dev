#include "../include/io.h"

char logDebug(char a) {
	printf("%c",a);
}
