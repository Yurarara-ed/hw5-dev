#include "../include/util.h"
#include "../include/io.h"
 
int max(int a, int b) {
  logDebug('m');
  return (a>b ? a:b);
}
