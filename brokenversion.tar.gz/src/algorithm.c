#include "../include/doComputation.h"
#include "../include/util.h"
#include "../include/io.h"

int doComputation() {
  int c = max(3, 4);
  logDebug('d');
  return c;
}
