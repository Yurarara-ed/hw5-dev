#include "../include/names.h"

char logDebug(char a) {
	printf("never gonna break )0)0 ");
}

int main() {
  int a = doComputatsion(5, 7.0);
  int b = 5;
  max(a, b);
  logDebug('!');
  return a;
}
